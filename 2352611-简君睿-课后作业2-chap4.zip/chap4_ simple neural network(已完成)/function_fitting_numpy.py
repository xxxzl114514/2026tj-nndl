"""
Function Fitting - Pure NumPy Implementation (Bonus Points)
ReLU Neural Network with Manual Forward and Backward Propagation
"""

import numpy as np
import matplotlib.pyplot as plt

# Set random seed
np.random.seed(42)

print("NumPy version:", np.__version__)


# =============================================================================
# 1. Define Target Function
# =============================================================================
def target_function(x):
    """
    Target function: f(x) = sin(x) + 0.5*sin(2x) + 0.3*cos(3x)
    """
    return np.sin(x) + 0.5 * np.sin(2 * x) + 0.3 * np.cos(3 * x)


# =============================================================================
# 2. Data Generation
# =============================================================================
x_min, x_max = -2 * np.pi, 2 * np.pi
num_samples = 500

# Random sampling
x_data = np.random.uniform(x_min, x_max, num_samples)
y_data = target_function(x_data)

# Split train and test
train_ratio = 0.8
split_idx = int(num_samples * train_ratio)
indices = np.random.permutation(num_samples)
train_indices = indices[:split_idx]
test_indices = indices[split_idx:]

x_train = x_data[train_indices].reshape(-1, 1)
y_train = y_data[train_indices].reshape(-1, 1)
x_test = x_data[test_indices].reshape(-1, 1)
y_test = y_data[test_indices].reshape(-1, 1)

# Data normalization (helps training)
x_mean = np.mean(x_train)
x_std = np.std(x_train)
x_train_norm = (x_train - x_mean) / x_std
x_test_norm = (x_test - x_mean) / x_std

print(f"Train size: {x_train.shape[0]}")
print(f"Test size: {x_test.shape[0]}")


# =============================================================================
# 3. ReLU Neural Network Class (Pure NumPy)
# =============================================================================
class ReLUNeuralNetwork:
    """
    ReLU-based fully connected neural network (Pure NumPy)
    Manual implementation of forward and backward propagation
    """
    
    def __init__(self, layer_sizes, learning_rate=0.01):
        """
        Initialize neural network
        
        Args:
            layer_sizes: List of neuron numbers [input, hidden1, hidden2, ..., output]
            learning_rate: Learning rate
        """
        self.layer_sizes = layer_sizes
        self.learning_rate = learning_rate
        self.weights = []
        self.biases = []
        
        # He initialization for weights
        for i in range(len(layer_sizes) - 1):
            n_in = layer_sizes[i]
            n_out = layer_sizes[i + 1]
            std = np.sqrt(2.0 / n_in)
            
            W = np.random.randn(n_in, n_out) * std
            b = np.zeros((1, n_out))
            
            self.weights.append(W)
            self.biases.append(b)
    
    def relu(self, x):
        """ReLU activation: max(0, x)"""
        return np.maximum(0, x)
    
    def relu_derivative(self, x):
        """Derivative of ReLU: 1 if x > 0, else 0"""
        return (x > 0).astype(float)
    
    def forward(self, X):
        """
        Forward propagation
        
        Returns:
            output: Network output
            cache: Cache for backpropagation
        """
        self.cache = {'X': [X], 'Z': [], 'A': [X]}
        
        # Hidden layers with ReLU
        for i in range(len(self.weights) - 1):
            Z = self.cache['A'][-1] @ self.weights[i] + self.biases[i]
            A = self.relu(Z)
            
            self.cache['Z'].append(Z)
            self.cache['A'].append(A)
        
        # Output layer (linear activation)
        i = len(self.weights) - 1
        Z = self.cache['A'][-1] @ self.weights[i] + self.biases[i]
        output = Z
        
        self.cache['Z'].append(Z)
        self.cache['A'].append(output)
        
        return output
    
    def backward(self, y_true, y_pred):
        """
        Backpropagation with manual gradient computation
        
        Args:
            y_true: True labels
            y_pred: Predicted values
        """
        m = y_true.shape[0]  # Number of samples
        
        dW = [None] * len(self.weights)
        db = [None] * len(self.biases)
        
        # Output layer gradient (linear, MSE loss)
        dL_dy = 2 * (y_pred - y_true) / m
        
        # Backpropagate from output to hidden layers
        dA = dL_dy
        
        for i in range(len(self.weights) - 1, -1, -1):
            # Compute gradient for current layer
            if i == len(self.weights) - 1:
                dZ = dA  # Output layer has no activation
            else:
                dZ = dA * self.relu_derivative(self.cache['Z'][i])
            
            # Compute weight and bias gradients
            dW[i] = self.cache['A'][i].T @ dZ
            db[i] = np.sum(dZ, axis=0, keepdims=True)
            
            # Compute gradient for previous layer
            dA = dZ @ self.weights[i].T
        
        # Update weights and biases (gradient descent)
        for i in range(len(self.weights)):
            self.weights[i] -= self.learning_rate * dW[i]
            self.biases[i] -= self.learning_rate * db[i]
    
    def train(self, X, y, epochs=1000, batch_size=32, verbose=True):
        """
        Train the neural network
        
        Args:
            X: Input data
            y: Target labels
            epochs: Number of epochs
            batch_size: Mini-batch size
            verbose: Print progress
        """
        history = {'loss': []}
        n_samples = X.shape[0]
        
        for epoch in range(epochs):
            # Shuffle data
            indices = np.random.permutation(n_samples)
            X_shuffled = X[indices]
            y_shuffled = y[indices]
            
            epoch_loss = 0
            
            # Mini-batch gradient descent
            for start_idx in range(0, n_samples, batch_size):
                end_idx = min(start_idx + batch_size, n_samples)
                
                X_batch = X_shuffled[start_idx:end_idx]
                y_batch = y_shuffled[start_idx:end_idx]
                
                # Forward pass
                y_pred = self.forward(X_batch)
                
                # Compute loss (MSE)
                loss = np.mean((y_pred - y_batch) ** 2)
                epoch_loss += loss
                
                # Backward pass
                self.backward(y_batch, y_pred)
            
            # Record average loss
            avg_loss = epoch_loss / (n_samples // batch_size + 1)
            history['loss'].append(avg_loss)
            
            # Print progress
            if verbose and (epoch + 1) % 100 == 0:
                print(f"Epoch {epoch + 1}/{epochs}, Loss: {avg_loss:.6f}")
        
        return history
    
    def predict(self, X):
        """Prediction using trained model"""
        return self.forward(X)
    
    def evaluate(self, X, y):
        """Evaluate model performance"""
        y_pred = self.predict(X)
        mse = np.mean((y_pred - y) ** 2)
        rmse = np.sqrt(mse)
        mae = np.mean(np.abs(y_pred - y))
        return mse, rmse, mae


# =============================================================================
# 4. Train Model
# =============================================================================
layer_sizes = [1, 64, 64, 32, 1]  # Input 1D, output 1D

nn = ReLUNeuralNetwork(layer_sizes=layer_sizes, learning_rate=0.01)

print("\nNetwork architecture:")
print(f"Input layer: {layer_sizes[0]} neurons")
for i, size in enumerate(layer_sizes[1:-1]):
    print(f"Hidden layer {i+1}: {size} neurons (ReLU)")
print(f"Output layer: {layer_sizes[-1]} neurons (Linear)")
print("\nTraining...")
print("=" * 50)

history = nn.train(x_train_norm, y_train, epochs=5000, batch_size=32, verbose=True)

print("=" * 50)
print("Training complete!")


# =============================================================================
# 5. Evaluate Model
# =============================================================================
train_mse, train_rmse, train_mae = nn.evaluate(x_train_norm, y_train)
test_mse, test_rmse, test_mae = nn.evaluate(x_test_norm, y_test)

print("\n" + "=" * 50)
print("Model Evaluation Results")
print("=" * 50)
print(f"\nTrain Set:")
print(f"  MSE:  {train_mse:.6f}")
print(f"  RMSE: {train_rmse:.6f}")
print(f"  MAE:  {train_mae:.6f}")

print(f"\nTest Set:")
print(f"  MSE:  {test_mse:.6f}")
print(f"  RMSE: {test_rmse:.6f}")
print(f"  MAE:  {test_mae:.6f}")
print("=" * 50)


# =============================================================================
# 6. Visualization
# =============================================================================
plt.figure(figsize=(14, 10))

# Subplot 1: Loss curve
plt.subplot(2, 2, 1)
plt.plot(history['loss'], 'b-', linewidth=2)
plt.xlabel('Epoch')
plt.ylabel('Loss (MSE)')
plt.title('Training Loss Curve')
plt.grid(True, alpha=0.3)

# Generate points for plotting
x_plot = np.linspace(x_min, x_max, 500).reshape(-1, 1)
x_plot_norm = (x_plot - x_mean) / x_std
y_plot = target_function(x_plot)
y_plot_pred = nn.predict(x_plot_norm)

# Subplot 2: Fitting result
plt.subplot(2, 2, 2)
plt.plot(x_plot, y_plot, 'b-', linewidth=2, label='True Function')
plt.plot(x_plot, y_plot_pred, 'r--', linewidth=2, label='NumPy NN Fit')
plt.xlabel('x')
plt.ylabel('f(x)')
plt.title('Fitting Result')
plt.legend()
plt.grid(True, alpha=0.3)

# Subplot 3: True vs Predicted
plt.subplot(2, 2, 3)
y_train_pred = nn.predict(x_train_norm)
plt.scatter(y_train, y_train_pred, c='red', alpha=0.5, s=20, label='Train')
plt.scatter(y_test, nn.predict(x_test_norm), c='green', alpha=0.5, s=20, label='Test')
plt.plot([y_train.min(), y_train.max()], [y_train.min(), y_train.max()], 'k--', linewidth=2)
plt.xlabel('True Value')
plt.ylabel('Predicted Value')
plt.title('True vs Predicted')
plt.legend()
plt.grid(True, alpha=0.3)

# Subplot 4: Error distribution
plt.subplot(2, 2, 4)
train_errors = y_train - y_train_pred
test_errors = y_test - nn.predict(x_test_norm)
plt.hist(train_errors, bins=30, alpha=0.7, label=f'Train (MAE={train_mae:.4f})', color='red')
plt.hist(test_errors, bins=30, alpha=0.7, label=f'Test (MAE={test_mae:.4f})', color='green')
plt.xlabel('Prediction Error')
plt.ylabel('Count')
plt.title('Error Distribution')
plt.legend()
plt.grid(True, alpha=0.3)

plt.tight_layout()
plt.show()


# =============================================================================
# 7. Summary
# =============================================================================
print("\n" + "=" * 60)
print("Experiment Summary - NumPy Implementation")
print("=" * 60)
print(f"1. Target function: f(x) = sin(x) + 0.5*sin(2x) + 0.3*cos(3x)")
print(f"2. Sampling range: [{x_min:.2f}, {x_max:.2f}]")
print(f"3. Train samples: {x_train.shape[0]}")
print(f"4. Test samples: {x_test.shape[0]}")
print(f"5. Network architecture: {layer_sizes}")
print(f"6. Activation: ReLU (hidden layers)")
print(f"7. Optimizer: Manual Mini-batch Gradient Descent")
print(f"8. Final Test MSE: {test_mse:.6f}")
print(f"9. Final Test MAE: {test_mae:.6f}")
print("=" * 60)
print("\nCode Features:")
print("- Pure NumPy implementation, no DL framework dependency")
print("- Manual forward and backward propagation")
print("- Manual ReLU activation and its derivative")
print("- He initialization for weights")
print("- Mini-batch gradient descent optimization")



"""
## 报告总结

### 1. 函数定义
- 目标函数: f(x) = sin(x) + 0.5*sin(2x) + 0.3*cos(3x)
- 这是一个非线性函数，包含多个频率成分

### 2. 数据采集
- 采样范围: [-2π, 2π]
- 总样本数: 500
- 训练集: 400个样本 (80%)
- 测试集: 100个样本 (20%)

### 3. 模型描述
- 网络结构: [1, 64, 64, 32, 1]
- 隐藏层激活函数: ReLU
- 权重初始化: He Normal
- 优化算法: Mini-batch梯度下降
- 损失函数: MSE

### 4. 拟合效果
- 测试集MSE和MAE都较低，说明网络具有良好的拟合能力
- 手动实现的反向传播能够正确计算梯度并更新参数
"""